	
PATCH 28186730: OPATCH 13.9.4.0.0 FOR FMW/WLS 12.2.1.3
		
Platform             : Generic
Product Patched      : Oracle Fusion Middleware 12c / Oracle WebLogic Server 12c
Product Version      : 12.2.1.3

	 
This is the README file for OPatch 13.9.4.0.0, the Oracle Interim One-off Patch Installer.

Notes
-----

Historically, OPatch was updated by unzipping and replacing ORACLE_HOME/OPatch directory.
For versions greater than or equal to 13.6, it now uses the OUI installation tooling. 
This ensures that installer both executes the file updates and logs the components and 
file changes to the OUI meta-data. A pure unzip install means the OUI tooling is 
not aware of these changes, which has on occasions led to upgrade related issues.

When extracted, this contains a 6880880 directory. This is because previous OPatch downloads 
are available as Patch 6880880. To avoid confusion with downloads not applicable to FMW/WLS, 
this new OPatch 13.9.4.0.0 placeholder was created as Patch 28186730. 


Pre-Installation Instructions 
----------------------------- 

1. Backup your <ORACLE_HOME>
 
2. Unzip this patch into your PATCH_HOME staging directory. 

3. This installer must be executed using a Java Development Kit (JDK). 
   - Set your PATH to include your <JDK_LOCATION>/bin


Installation
----------------------------------
 
1. Install the software with the following command:

    UNIX Only:
	java -jar <PATCH_HOME>/6880880/opatch_generic.jar -silent oracle_home=<ORACLE_HOME_LOCATION>
	
	Note: If you have /tmp is set with a noexec flag, you can override the tmp with the -D argument:
	java opatch_generic.jar -Djava.io.tmpdir=/opt/oracle -jar -silent oracle_home=<ORACLE_HOME_LOCATION>
	
	Windows Only:
	java -jar opatch_generic.jar -J-Doracle.installer.oh_admin_acl=true -silent oracle_home=<ORACLE_HOME_LOCATION>


where ORACLE_HOME_LOCATION is the absolute path where you have installed FMW/WLS products.

If using a custom Inventory location, install the software with the following command:
    
    java -jar <PATCH_HOME>/6880880/opatch_generic.jar -silent oracle_home=<ORACLE_HOME_LOCATION> -invPtrLoc <INVENTORY_LOCATION>

where INVENTORY_LOCATION is the absolute path to the oraInst.loc file.



2. To validate the installation:

    cd <ORACLE_HOME>/OPatch
    opatch version
    opatch lspatches
 
 
Post-installation Instructions
----------------------------------

When applying interim patches with OPatch 13.9.4, Microsoft Windows platform needs the '-oop' option:

<ORACLE_HOME>/OPatch/opatch apply <PATCH_HOME> -oop

where PATCH_HOME is a numbered directory where you extracted interim patch contents.

Follow interim patch readmes for other installation steps to apply patches.

 
Deinstallation
--------------

There is no mechanism to revert OPatch to an older version.

To revert OPatch, restore the backup for your ORACLE_HOME

 
Documentation and Help
-----------------------

To obtain command names or options from the command prompt, use:

    opatch -help
    opatch napply -help
 
To learn about patching with the OPatch utility with FMW/WLS 12c:

Doc ID 1587524.1 Using OUI NextGen OPatch 13 for Oracle Fusion Middleware 12c (12.1.2+)

 

New Features and Bugs Fixed List
---------------------------------

1. Replacement in Use Feature (-oop), OPatch wil be able to patch files which are in use (being used by other application)